-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Дек 01 2025 г., 07:59
-- Версия сервера: 8.0.34-26-beget-1-1
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `oksiv92_clash`
--

-- --------------------------------------------------------

--
-- Структура таблицы `rate_limits`
--
-- Создание: Ноя 08 2025 г., 09:07
--

DROP TABLE IF EXISTS `rate_limits`;
CREATE TABLE `rate_limits` (
  `key` varchar(255) NOT NULL,
  `count` int DEFAULT '0',
  `timestamp` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Ноя 08 2025 г., 09:07
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `login` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gold` int NOT NULL DEFAULT '500',
  `elixir` int NOT NULL DEFAULT '200',
  `townhall_lvl` int NOT NULL DEFAULT '1',
  `last_update` int NOT NULL,
  `login_attempts` int DEFAULT '0',
  `last_attempt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `gold`, `elixir`, `townhall_lvl`, `last_update`, `login_attempts`, `last_attempt`) VALUES
(1, 'Admin', '$2y$10$wRU7bp5bk5WdosCS2s7Fi.pAX1KpiEqfxVWOe/JAr67nOjncG4gWW', 1000000, 1000000, 1, 1756994691, 0, '2025-08-19 14:42:48'),
(2, 'Angelok', '$2y$12$KwV4mzbJkbiDHzCyzD/3b.rmVpxWks8MzJNZMY0BxGNme/fLTrBxq', 630, 265, 1, 1751013097, 1, '2025-06-27 11:34:22'),
(3, 'Bakss2009', '$2y$12$DfED.Vc7QwWKKfwq0J7GY.rjsq7jbKZfhsfLodfXla7D2ddkCa.3q', 500, 200, 1, 1751013282, 0, NULL),
(4, 'Barmaley', '$2y$12$wSfdAN4jUhNQGq7asCabje3XTwe/tfvEoaYOZxOQjZxmN5ZRbzKza', 784, 329, 1, 1751016675, 0, NULL),
(5, 'Error404', '$2y$12$yDBmA2QTI/W5av1XBaEJze1PjjdMnODnwssrIbp4SINjcp0NnyufG', 16792, 8313, 1, 1751035993, 0, NULL),
(6, 'test', '$2y$12$s3jlofHWCx.OJ1RxCtJtieOs3YmhbX56UU98fuusUwkX60xA4o6oK', 289024, 144241, 1, 1753458952, 0, '2025-07-22 15:00:51'),
(7, 'Admin22', '$2y$12$6CLnX/gxCNBdjOjzuacY.efVCTGbHLtVuADQd1jKYLroGxkZDRoiG', 1000000, 639974, 1, 1755965054, 0, NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `rate_limits`
--
ALTER TABLE `rate_limits`
  ADD PRIMARY KEY (`key`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
